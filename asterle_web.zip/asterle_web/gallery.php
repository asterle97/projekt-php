<?php
print '
		<div class="gallery" >
			<h1>Gallery</h1>
			<figure>
			<a href="gallery/holandska kuća.png" alt="" target="_blank"><img src="gallery/holandska kuća.png" width="350" height="257"></a>
			<figcaption>Holandska kuća (Dutch house)</figcaption>
			</figure>
			<figure>
			<a href="gallery/iskopine.png" alt="" target="_blank"><img src="gallery/iskopine.png" width="350" height="257"></a>
			<figcaption>Iskopine Siscie (Excavations of Siscia)</figcaption>
			</figure>
			<figure>
			<a href="gallery/stari grad1.png" alt="" target="_blank"><img src="gallery/stari grad1.png" width="350" height="257"></a>
			<figcaption>Stari grad (Old town)</figcaption>
			</figure>
			<figure>
			<a href="gallery/stari most.png" alt="" target="_blank"><img src="gallery/stari most.png" width="350" height="257"></a>
			<figcaption>Stari most (Old bridge)</figcaption>
			</figure>
			<figure>
			<a href="gallery/šetnica.png" alt="" target="_blank"><img src="gallery/šetnica.png" width="350" height="257"></a>
			<figcaption>Šetnica (Walking trail)</figcaption>
			</figure>
		</div>';
?>