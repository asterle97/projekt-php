<?php
	$MySQL = mysqli_connect("localhost","root","","projekt_web") or die('Error while conncting to database.');
?>