<?php
print '
		<div class="frame">
			<h1> Map and contact</h1>
			<p>email: asterle@vvg.hr</p>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d44764.21699443632!2d16.355701647334026!3d45.47456659973518!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4766e5306f2ca433%3A0x400ad50862bbab0!2sSisak!5e0!3m2!1sen!2shr!4v1548776097475" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
		</div>';
?>
